from __future__ import annotations

import argparse
import subprocess
import sys


def run(cmd: list[str]) -> None:
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/v4.yaml")
    args = parser.parse_args()
    run([sys.executable, "scripts/make_splits.py", "--config", args.config])
    run([sys.executable, "scripts/run_experiments.py", "--config", args.config])
    run([sys.executable, "scripts/generate_figures.py", "--config", args.config])


if __name__ == "__main__":
    main()


from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)


def metric_row(model_name: str, y_true: np.ndarray, y_pred: np.ndarray, y_prob: np.ndarray) -> dict:
    return {
        "model": model_name,
        "accuracy": accuracy_score(y_true, y_pred),
        "macro_precision": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "macro_recall": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "macro_f1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "weighted_f1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "auc_ovr": roc_auc_score(y_true, y_prob, multi_class="ovr", average="macro"),
    }


def calibration_metrics(y_true: np.ndarray, y_prob: np.ndarray, n_bins: int = 10) -> dict:
    y_onehot = np.eye(y_prob.shape[1])[y_true]
    brier = np.mean(np.sum((y_prob - y_onehot) ** 2, axis=1))
    conf = y_prob.max(axis=1)
    pred = y_prob.argmax(axis=1)
    correct = (pred == y_true).astype(float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    bin_rows = []
    for i in range(n_bins):
        mask = (conf >= bins[i]) & (conf < bins[i + 1] if i < n_bins - 1 else conf <= bins[i + 1])
        if not np.any(mask):
            continue
        acc = correct[mask].mean()
        avg_conf = conf[mask].mean()
        weight = mask.mean()
        ece += weight * abs(acc - avg_conf)
        bin_rows.append(
            {
                "bin": i,
                "confidence": avg_conf,
                "accuracy": acc,
                "count": int(mask.sum()),
            }
        )
    return {
        "brier_score": float(brier),
        "ece": float(ece),
        "nll": float(log_loss(y_true, y_prob)),
        "bins": pd.DataFrame(bin_rows),
    }


def save_confusion(y_true: np.ndarray, y_pred: np.ndarray, out_path: str) -> None:
    labels = [0, 1, 2]
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    df = pd.DataFrame(cm, index=["low", "moderate", "high"], columns=["pred_low", "pred_moderate", "pred_high"])
    df.insert(0, "true_label", df.index)
    df.to_csv(out_path, index=False)


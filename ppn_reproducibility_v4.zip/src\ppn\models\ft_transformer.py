from __future__ import annotations

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from ppn.models.ppn import set_seed


class _FTTransformerNet(nn.Module):
    def __init__(self, n_features: int, d_token: int = 64, n_heads: int = 4, n_layers: int = 3, dropout: float = 0.1):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(n_features, d_token) * 0.02)
        self.bias = nn.Parameter(torch.zeros(n_features, d_token))
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_token,
            nhead=n_heads,
            dim_feedforward=d_token * 4,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.head = nn.Sequential(nn.LayerNorm(d_token), nn.Linear(d_token, 3))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = x.unsqueeze(-1) * self.weight.unsqueeze(0) + self.bias.unsqueeze(0)
        z = self.encoder(tokens).mean(dim=1)
        return self.head(z)


class SimpleFTTransformerClassifier:
    """Small FT-Transformer-style classifier for continuous/ordinal tabular inputs."""

    def __init__(
        self,
        seed: int = 2021,
        d_token: int = 64,
        n_heads: int = 4,
        n_layers: int = 3,
        dropout: float = 0.1,
        learning_rate: float = 0.001,
        batch_size: int = 32,
        max_epochs: int = 200,
    ) -> None:
        self.seed = seed
        self.d_token = d_token
        self.n_heads = n_heads
        self.n_layers = n_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.max_epochs = max_epochs
        self.model_: _FTTransformerNet | None = None

    def fit(self, x: np.ndarray, y: np.ndarray):
        set_seed(self.seed)
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model = _FTTransformerNet(
            n_features=x.shape[1],
            d_token=self.d_token,
            n_heads=self.n_heads,
            n_layers=self.n_layers,
            dropout=self.dropout,
        ).to(device)
        opt = torch.optim.AdamW(model.parameters(), lr=self.learning_rate, weight_decay=1e-5)
        loss_fn = nn.CrossEntropyLoss()
        ds = TensorDataset(torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.long))
        loader = DataLoader(ds, batch_size=self.batch_size, shuffle=True)
        model.train()
        for _ in range(self.max_epochs):
            for xb, yb in loader:
                xb = xb.to(device)
                yb = yb.to(device)
                opt.zero_grad(set_to_none=True)
                loss = loss_fn(model(xb), yb)
                loss.backward()
                opt.step()
        self.model_ = model
        return self

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        if self.model_ is None:
            raise RuntimeError("Model has not been fitted.")
        device = next(self.model_.parameters()).device
        self.model_.eval()
        with torch.no_grad():
            logits = self.model_(torch.tensor(x, dtype=torch.float32, device=device))
            return torch.softmax(logits, dim=1).detach().cpu().numpy()

    def predict(self, x: np.ndarray) -> np.ndarray:
        return self.predict_proba(x).argmax(axis=1)


from __future__ import annotations

import shutil
from pathlib import Path


DATASETS = {
    "rxnach/student-stress-factors-a-comprehensive-analysis": "student_stress_factors.csv",
    "mdsultanulislamovi/student-stress-monitoring-datasets": "student_stress_monitoring.csv",
}


def copy_first_csv(download_dir: Path, target: Path) -> None:
    csvs = sorted(download_dir.rglob("*.csv"))
    if not csvs:
        raise FileNotFoundError(f"No CSV files found in {download_dir}")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(csvs[0], target)
    print(f"Copied {csvs[0]} -> {target}")


def main() -> None:
    try:
        import kagglehub
    except Exception as exc:
        raise SystemExit(
            "kagglehub is not installed or not configured. Install requirements and configure Kaggle credentials."
        ) from exc
    raw_dir = Path("data/raw")
    for slug, filename in DATASETS.items():
        print(f"Downloading {slug} ...")
        path = Path(kagglehub.dataset_download(slug))
        copy_first_csv(path, raw_dir / filename)


if __name__ == "__main__":
    main()


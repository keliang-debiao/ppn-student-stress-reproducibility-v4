from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


@dataclass
class PreparedSplit:
    x_train: np.ndarray
    y_train: np.ndarray
    x_val: np.ndarray
    y_val: np.ndarray
    x_test: np.ndarray
    y_test: np.ndarray
    train_indices: np.ndarray
    val_indices: np.ndarray
    test_indices: np.ndarray
    feature_names: list[str]
    scaler: StandardScaler
    imputer: SimpleImputer


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = (
        df.columns.astype(str)
        .str.strip()
        .str.replace(" ", "_", regex=False)
        .str.replace("-", "_", regex=False)
        .str.replace("/", "_", regex=False)
        .str.lower()
    )
    return df


def load_main_dataset(csv_path: str | Path, target_col: str) -> pd.DataFrame:
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(
            f"Missing raw dataset: {path}. Download the Kaggle CSV and place it at this path."
        )
    df = normalize_columns(pd.read_csv(path))
    target_col = target_col.lower()
    if target_col not in df.columns:
        candidates = [c for c in df.columns if "stress" in c and "level" in c]
        if candidates:
            df = df.rename(columns={candidates[0]: target_col})
        else:
            raise ValueError(f"Could not find target column {target_col!r}.")
    df[target_col] = df[target_col].astype(int)
    return df


def select_features(df: pd.DataFrame, requested: Iterable[str], target_col: str) -> list[str]:
    requested = [x.lower() for x in requested]
    missing = [x for x in requested if x not in df.columns]
    if missing:
        available = [c for c in df.columns if c != target_col]
        raise ValueError(
            "Requested manuscript features are missing from the CSV: "
            + ", ".join(missing)
            + f". Available non-target columns: {available}"
        )
    return requested


def make_fixed_class_split(
    df: pd.DataFrame,
    target_col: str,
    fixed_test_counts: dict[int, int],
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    test_indices: list[int] = []
    train_indices: list[int] = []
    for cls, test_count in fixed_test_counts.items():
        cls_idx = df.index[df[target_col] == int(cls)].to_numpy()
        rng.shuffle(cls_idx)
        test_indices.extend(cls_idx[: int(test_count)].tolist())
        train_indices.extend(cls_idx[int(test_count) :].tolist())
    return np.array(sorted(train_indices)), np.array(sorted(test_indices))


def make_train_val_split(
    y_train_full: np.ndarray,
    train_full_indices: np.ndarray,
    val_size: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    train_indices: list[int] = []
    val_indices: list[int] = []
    for cls in sorted(np.unique(y_train_full)):
        local_positions = np.where(y_train_full == cls)[0]
        rng.shuffle(local_positions)
        n_val = max(1, int(round(len(local_positions) * val_size)))
        val_indices.extend(train_full_indices[local_positions[:n_val]].tolist())
        train_indices.extend(train_full_indices[local_positions[n_val:]].tolist())
    return np.array(sorted(train_indices)), np.array(sorted(val_indices))


def prepare_split(df: pd.DataFrame, cfg: dict, seed: int) -> PreparedSplit:
    target_col = cfg["data"]["target_col"].lower()
    features = select_features(df, cfg["data"]["numeric_or_ordinal_features"], target_col)
    fixed_counts = {int(k): int(v) for k, v in cfg["data"]["fixed_test_counts"].items()}
    train_full_idx, test_idx = make_fixed_class_split(
        df=df,
        target_col=target_col,
        fixed_test_counts=fixed_counts,
        seed=int(cfg["training"]["split_seed"]),
    )
    y_train_full = df.loc[train_full_idx, target_col].to_numpy()
    train_idx, val_idx = make_train_val_split(
        y_train_full=y_train_full,
        train_full_indices=train_full_idx,
        val_size=float(cfg["training"]["validation_size"]),
        seed=seed,
    )

    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    x_train_raw = df.loc[train_idx, features].to_numpy(dtype=float)
    x_val_raw = df.loc[val_idx, features].to_numpy(dtype=float)
    x_test_raw = df.loc[test_idx, features].to_numpy(dtype=float)

    x_train = scaler.fit_transform(imputer.fit_transform(x_train_raw))
    x_val = scaler.transform(imputer.transform(x_val_raw))
    x_test = scaler.transform(imputer.transform(x_test_raw))

    return PreparedSplit(
        x_train=x_train,
        y_train=df.loc[train_idx, target_col].to_numpy(dtype=int),
        x_val=x_val,
        y_val=df.loc[val_idx, target_col].to_numpy(dtype=int),
        x_test=x_test,
        y_test=df.loc[test_idx, target_col].to_numpy(dtype=int),
        train_indices=train_idx,
        val_indices=val_idx,
        test_indices=test_idx,
        feature_names=features,
        scaler=scaler,
        imputer=imputer,
    )


def save_split_indices(split: PreparedSplit, out_path: str | Path) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, values in [
        ("train", split.train_indices),
        ("validation", split.val_indices),
        ("test", split.test_indices),
    ]:
        for idx in values:
            rows.append({"split": name, "row_index": int(idx)})
    pd.DataFrame(rows).to_csv(out_path, index=False)


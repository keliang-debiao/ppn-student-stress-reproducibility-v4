from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


def save_performance_figure(metrics: pd.DataFrame, out_path: str | Path) -> None:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cols = ["accuracy", "macro_f1", "balanced_accuracy", "auc_ovr"]
    plot_df = metrics.melt(id_vars="model", value_vars=cols, var_name="metric", value_name="value")
    plt.figure(figsize=(10, 5), dpi=300)
    sns.barplot(data=plot_df, x="model", y="value", hue="metric")
    plt.ylim(0.78, 1.0)
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


def save_confusion_heatmap(cm_csv: str | Path, out_path: str | Path) -> None:
    out_path = Path(out_path)
    df = pd.read_csv(cm_csv)
    mat = df[["pred_low", "pred_moderate", "pred_high"]].to_numpy()
    plt.figure(figsize=(6, 5), dpi=300)
    sns.heatmap(
        mat,
        annot=True,
        fmt="d",
        cmap="Blues",
        cbar=False,
        xticklabels=["Low", "Moderate", "High"],
        yticklabels=["Low", "Moderate", "High"],
    )
    plt.xlabel("Predicted class")
    plt.ylabel("True class")
    plt.title("Corrected PPN Three-Class Confusion Matrix")
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


def save_calibration_figure(bins_csv: str | Path, out_path: str | Path) -> None:
    out_path = Path(out_path)
    bins = pd.read_csv(bins_csv)
    plt.figure(figsize=(6, 5), dpi=300)
    plt.plot([0, 1], [0, 1], "--", color="0.4", label="Perfect calibration")
    if not bins.empty:
        plt.plot(bins["confidence"], bins["accuracy"], marker="o", label="PPN after temp.")
    plt.xlabel("Confidence")
    plt.ylabel("Accuracy")
    plt.title("Top-label Reliability Diagram")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


from __future__ import annotations

import argparse
from pathlib import Path

from ppn.config import load_config
from ppn.data import load_main_dataset, prepare_split, save_split_indices


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/v4.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    df = load_main_dataset(cfg["data"]["main_csv"], cfg["data"]["target_col"])
    split = prepare_split(df, cfg, seed=int(cfg["training"]["split_seed"]))
    out = Path("data/processed") / f"split_indices_seed{cfg['training']['split_seed']}.csv"
    save_split_indices(split, out)
    print(out)


if __name__ == "__main__":
    main()


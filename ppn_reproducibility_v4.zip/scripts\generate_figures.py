from __future__ import annotations

import argparse
from pathlib import Path

from ppn.config import ensure_dir, load_config
from ppn.figures import save_calibration_figure, save_confusion_heatmap, save_performance_figure


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/v4.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    out_dir = Path(cfg["project"]["output_dir"])
    fig_dir = ensure_dir(out_dir / "figures")
    save_performance_figure(out_dir / "main_metrics.csv", fig_dir / "figure5_performance.png")
    save_calibration_figure(out_dir / "calibration_bins.csv", fig_dir / "figure7_calibration.png")
    save_confusion_heatmap(out_dir / "confusion_matrix.csv", fig_dir / "figure8_confusion.png")
    print(fig_dir)


if __name__ == "__main__":
    main()


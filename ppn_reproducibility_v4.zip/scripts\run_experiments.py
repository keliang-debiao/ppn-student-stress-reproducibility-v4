from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from ppn.baselines import fit_predict_proba, make_baselines
from ppn.config import ensure_dir, load_config
from ppn.data import load_main_dataset, prepare_split, save_split_indices
from ppn.evaluate import calibration_metrics, metric_row, save_confusion
from ppn.models.ppn import predict_ppn, train_ppn
from ppn.prototypes import nearest_neighbor_feature_summaries


def run_one_seed(cfg: dict, seed: int, out_dir: Path) -> pd.DataFrame:
    df = load_main_dataset(cfg["data"]["main_csv"], cfg["data"]["target_col"])
    split = prepare_split(df, cfg, seed=seed)
    save_split_indices(split, Path("data/processed") / f"split_indices_seed{seed}.csv")

    rows = []
    for name, model in make_baselines(seed).items():
        pred, prob = fit_predict_proba(model, split.x_train, split.y_train, split.x_test)
        rows.append(metric_row(name, split.y_test, pred, prob))

    result = train_ppn(split.x_train, split.y_train, split.x_val, split.y_val, cfg, seed)
    ppn_pred, ppn_prob, ppn_dist = predict_ppn(result.model, split.x_test)
    rows.append(metric_row("PPN", split.y_test, ppn_pred, ppn_prob))

    if seed == int(cfg["training"]["split_seed"]):
        save_confusion(split.y_test, ppn_pred, out_dir / "confusion_matrix.csv")
        cal = calibration_metrics(split.y_test, ppn_prob)
        pd.DataFrame([{k: v for k, v in cal.items() if k != "bins"}]).to_csv(out_dir / "calibration_metrics.csv", index=False)
        cal["bins"].to_csv(out_dir / "calibration_bins.csv", index=False)
        train_pred, train_prob, train_dist = predict_ppn(result.model, split.x_train)
        proto_df = nearest_neighbor_feature_summaries(
            split.x_train,
            split.y_train,
            train_dist,
            split.feature_names,
            result.model.prototype_classes.detach().cpu().numpy(),
            k_neighbors=50,
        )
        proto_df.to_csv(out_dir / "prototype_feature_means_sd.csv", index=False)
        torch.save(result.model.state_dict(), out_dir / "ppn_seed2021.pt")
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/v4.yaml")
    args = parser.parse_args()
    cfg = load_config(args.config)
    out_dir = ensure_dir(cfg["project"]["output_dir"])
    all_rows = []
    for seed in cfg["seeds"]:
        seed_rows = run_one_seed(cfg, int(seed), out_dir)
        seed_rows.insert(0, "seed", int(seed))
        all_rows.append(seed_rows)
    long_df = pd.concat(all_rows, ignore_index=True)
    long_df.to_csv(out_dir / "repeated_seed_metrics.csv", index=False)
    main = long_df[long_df["seed"] == int(cfg["training"]["split_seed"])].drop(columns=["seed"])
    main.to_csv(out_dir / "main_metrics.csv", index=False)
    summary = long_df.groupby("model").agg(["mean", "std"])
    summary.to_csv(out_dir / "repeated_seed_summary.csv")
    print(out_dir)


if __name__ == "__main__":
    main()


from __future__ import annotations

import numpy as np
import pandas as pd


def nearest_neighbor_feature_summaries(
    x_train: np.ndarray,
    y_train: np.ndarray,
    distances_train: np.ndarray,
    feature_names: list[str],
    prototype_classes: np.ndarray,
    k_neighbors: int = 50,
) -> pd.DataFrame:
    rows = []
    for p_idx, cls in enumerate(prototype_classes):
        order = np.argsort(distances_train[:, p_idx])[:k_neighbors]
        subset = x_train[order]
        means = subset.mean(axis=0)
        sds = subset.std(axis=0, ddof=1)
        top = np.argsort(np.abs(means))[-4:][::-1]
        summary = "; ".join(
            f"{feature_names[j]}: {means[j]:+.2f} +/- {sds[j]:.2f}" for j in top
        )
        purity = float((y_train[order] == cls).mean())
        rows.append(
            {
                "prototype": f"P{p_idx + 1}",
                "assigned_class": int(cls),
                "nearest_neighbor_purity": purity,
                "top_features": "; ".join(feature_names[j] for j in top),
                "mean_sd_standardized": summary,
                "representative_nearest_case": f"train_case_{int(order[0]):04d}",
            }
        )
    return pd.DataFrame(rows)


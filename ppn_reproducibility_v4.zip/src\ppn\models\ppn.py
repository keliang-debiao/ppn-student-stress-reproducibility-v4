from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class PsychoPrototypicalNetwork(nn.Module):
    def __init__(
        self,
        input_dim: int,
        num_classes: int = 3,
        d_model: int = 64,
        hidden_dim: int = 128,
        num_prototypes: int = 6,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.num_classes = num_classes
        self.num_prototypes = num_prototypes
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, d_model),
        )
        self.prototypes = nn.Parameter(torch.randn(num_prototypes, d_model) * 0.05)
        self.classifier = nn.Linear(num_prototypes, num_classes)
        per_class = int(np.ceil(num_prototypes / num_classes))
        proto_classes = torch.arange(num_classes).repeat_interleave(per_class)[:num_prototypes]
        self.register_buffer("prototype_classes", proto_classes.long())

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)

    def distances(self, z: torch.Tensor) -> torch.Tensor:
        return torch.cdist(z, self.prototypes, p=2).pow(2)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        z = self.encode(x)
        d = self.distances(z)
        logits = self.classifier(-d)
        return logits, d, z


def prototype_losses(
    distances: torch.Tensor,
    y: torch.Tensor,
    prototype_classes: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    same = prototype_classes.unsqueeze(0) == y.unsqueeze(1)
    diff = ~same
    compact = distances.masked_fill(~same, float("inf")).min(dim=1).values.mean()
    separation = -distances.masked_fill(~diff, float("inf")).min(dim=1).values.mean()
    return compact, separation


@dataclass
class TrainResult:
    model: PsychoPrototypicalNetwork
    best_val_loss: float


def train_ppn(
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_val: np.ndarray,
    y_val: np.ndarray,
    cfg: dict,
    seed: int,
) -> TrainResult:
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ppn_cfg = cfg["ppn"]
    model = PsychoPrototypicalNetwork(
        input_dim=x_train.shape[1],
        num_classes=3,
        d_model=int(ppn_cfg["d_model"]),
        hidden_dim=int(ppn_cfg["hidden_dim"]),
        num_prototypes=int(ppn_cfg["num_prototypes"]),
        dropout=float(ppn_cfg["dropout"]),
    ).to(device)
    opt = torch.optim.AdamW(
        model.parameters(),
        lr=float(ppn_cfg["learning_rate"]),
        weight_decay=float(ppn_cfg["weight_decay"]),
    )
    ce = nn.CrossEntropyLoss()
    batch_size = int(cfg["training"]["batch_size"])
    ds = TensorDataset(
        torch.tensor(x_train, dtype=torch.float32),
        torch.tensor(y_train, dtype=torch.long),
    )
    loader = DataLoader(ds, batch_size=batch_size, shuffle=True)
    x_val_t = torch.tensor(x_val, dtype=torch.float32, device=device)
    y_val_t = torch.tensor(y_val, dtype=torch.long, device=device)
    best_state = None
    best_loss = float("inf")
    patience = int(cfg["training"]["early_stopping_patience"])
    stale = 0
    for _epoch in range(int(cfg["training"]["epochs"])):
        model.train()
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            logits, distances, _ = model(xb)
            compact, separation = prototype_losses(distances, yb, model.prototype_classes)
            loss = ce(logits, yb) + float(ppn_cfg["alpha"]) * compact + float(ppn_cfg["beta"]) * separation
            loss.backward()
            opt.step()
        model.eval()
        with torch.no_grad():
            logits, distances, _ = model(x_val_t)
            compact, separation = prototype_losses(distances, y_val_t, model.prototype_classes)
            val_loss = ce(logits, y_val_t) + float(ppn_cfg["alpha"]) * compact + float(ppn_cfg["beta"]) * separation
            val_loss_f = float(val_loss.detach().cpu())
        if val_loss_f < best_loss:
            best_loss = val_loss_f
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
            if stale >= patience:
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return TrainResult(model=model, best_val_loss=best_loss)


def predict_ppn(model: PsychoPrototypicalNetwork, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    device = next(model.parameters()).device
    model.eval()
    with torch.no_grad():
        logits, distances, z = model(torch.tensor(x, dtype=torch.float32, device=device))
        probs = torch.softmax(logits, dim=1).detach().cpu().numpy()
        pred = probs.argmax(axis=1)
    return pred, probs, distances.detach().cpu().numpy()

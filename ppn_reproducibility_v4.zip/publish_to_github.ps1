param(
    [string]$RepoName = "ppn-student-stress-reproducibility-v4",
    [string]$Description = "Reproducibility package for the V4 Psycho-Prototypical Network student stress manuscript.",
    [switch]$Private
)

$ErrorActionPreference = "Stop"

$token = [Environment]::GetEnvironmentVariable("GITHUB_TOKEN")
if (-not $token) {
    throw "Set GITHUB_TOKEN to a GitHub personal access token with repo creation permissions, then rerun this script."
}

$headers = @{
    Authorization = "Bearer $token"
    Accept = "application/vnd.github+json"
    "X-GitHub-Api-Version" = "2022-11-28"
}

$user = Invoke-RestMethod -Method Get -Uri "https://api.github.com/user" -Headers $headers
$body = @{
    name = $RepoName
    description = $Description
    private = [bool]$Private
    auto_init = $false
} | ConvertTo-Json

try {
    $repo = Invoke-RestMethod -Method Post -Uri "https://api.github.com/user/repos" -Headers $headers -Body $body -ContentType "application/json"
} catch {
    if ($_.Exception.Response.StatusCode.value__ -eq 422) {
        $repo = Invoke-RestMethod -Method Get -Uri "https://api.github.com/repos/$($user.login)/$RepoName" -Headers $headers
    } else {
        throw
    }
}

if ((git remote) -contains "origin") {
    git remote set-url origin $repo.clone_url
} else {
    git remote add origin $repo.clone_url
}

git -c "http.extraheader=AUTHORIZATION: bearer $token" push -u origin main
Write-Output $repo.html_url

